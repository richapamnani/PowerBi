# PowerBi
This project is on Purchase Data , I have done Analyzes by Power Bi Dashboard
